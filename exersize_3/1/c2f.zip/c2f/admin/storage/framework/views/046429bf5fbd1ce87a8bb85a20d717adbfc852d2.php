<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('public/css/material-dashboard.css'), false); ?>" >

  <link rel="stylesheet" href="<?php echo e(asset('public/css/demo.css'), false); ?>" >

</head>
<body>


<main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>


   <script src="<?php echo e(asset('public/js/jquery.min.js'), false); ?>"></script>
   <script src="<?php echo e(asset('public/js/popper.min.js'), false); ?>"></script>
   <script src="<?php echo e(asset('public/js/bootstrap-material-design.min.js'), false); ?>"></script>
</html>
<?php /**PATH C:\xampp\htdocs\tarunfirst\resources\views/layouts/admin.blade.php ENDPATH**/ ?>