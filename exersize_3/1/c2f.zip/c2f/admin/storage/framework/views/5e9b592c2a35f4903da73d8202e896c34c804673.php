<?php $__env->startSection('content'); ?>
<section class="cmspage mtb-40">
        <div class="container">
          <div class="page-desc">
            <div class="row justify-content-center">
              <div class="col-md-8">
              
              <h1><?php echo e(Session::get('data')); ?></h1>

                <h1>Contact</h1>
                <form method="post" action="create">
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="Name">
                  </div>
                  <div class="form-group">
                    <input type="text" name="email" class="form-control" placeholder="E-Mail">
                  </div>
                  <div class="form-group">
                    <input type="text" name="phone" class="form-control" placeholder="Phone">
                  </div>
                  <div class="form-group">
                    <textarea name="message" rows="5" class="form-control" placeholder="Message"></textarea>
                  </div>
                  <div class="form-group">
                    <button class="btn btn-success">Send Message</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tarunfirst\resources\views/contact.blade.php ENDPATH**/ ?>