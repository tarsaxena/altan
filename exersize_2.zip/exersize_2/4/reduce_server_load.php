//Checking the server load

$ uptime
13:40:40 up 38 days, 1:07, 1 user, load average: 0.25, 0.14, 0.14


//Understanding the server load
grep processor /proc/cpuinfo | wc -l



More tips to reduce your server load#
1. Optimize your images#
2. Compress your CSS#
3. Compress your data#
4. Host your images elsewhere