<h1 align="center">Home</h1>
<a href="javascript:void(0)" id="recordList">Record recordList</a>
<div id="loadcontent"></div>