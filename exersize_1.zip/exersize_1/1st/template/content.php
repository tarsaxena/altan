<?php require 'header.php' ?>
<?php require $content ?>
<?php require 'footer.php' ?>