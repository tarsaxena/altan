<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	 <script src="asset/js/jquery.min.js"></script>
	 <link rel="stylesheet" type="text/css" href="asset/css/custom.css">
	 <link rel="stylesheet" type="text/css" href="asset/css/bootstrap.min.css">
</head>
   <body>

  